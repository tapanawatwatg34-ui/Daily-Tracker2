/* =====================================================
   HEALTH TRACKER
===================================================== */


/* =====================================================
   DATA
===================================================== */

let healthData =
    JSON.parse(
        localStorage.getItem(
            "healthTrackerData"
        )
    ) || [];



/* =====================================================
   DOM
===================================================== */

const form =
    document.getElementById(
        "healthForm"
    );

const inputPage =
    document.getElementById(
        "inputPage"
    );

const resultsPage =
    document.getElementById(
        "resultsPage"
    );

const dateInput =
    document.getElementById(
        "date"
    );

const readingInput =
    document.getElementById(
        "reading"
    );

const exerciseInput =
    document.getElementById(
        "exercise"
    );

const exerciseTypeInput =
    document.getElementById(
        "exerciseType"
    );

const customExerciseGroup =
    document.getElementById(
        "customExerciseGroup"
    );

const customExerciseInput =
    document.getElementById(
        "customExercise"
    );

const scoreInput =
    document.getElementById(
        "score"
    );

const scoreValue =
    document.getElementById(
        "scoreValue"
    );

const savedMessage =
    document.getElementById(
        "savedMessage"
    );

const showResultsButton =
    document.getElementById(
        "showResultsButton"
    );

const backToInputButton =
    document.getElementById(
        "backToInputButton"
    );

const clearAllButton =
    document.getElementById(
        "clearAllButton"
    );

const moodTracker =
    document.getElementById(
        "moodTracker"
    );

const historyList =
    document.getElementById(
        "historyList"
    );

const calendarDays =
    document.getElementById(
        "calendarDays"
    );

const calendarTitle =
    document.getElementById(
        "calendarTitle"
    );

const prevMonthButton =
    document.getElementById(
        "prevMonth"
    );

const nextMonthButton =
    document.getElementById(
        "nextMonth"
    );



/* =====================================================
   MOOD CONFIG
===================================================== */

const moodConfig = {

    "เศร้า": {

        emoji: "😢",

        bulbClass:
            "bulb-sad",

        calendarClass:
            "mood-sad"

    },


    "เหนื่อย": {

        emoji: "😮‍💨",

        bulbClass:
            "bulb-tired",

        calendarClass:
            "mood-tired"

    },


    "เฉยๆ": {

        emoji: "😐",

        bulbClass:
            "bulb-normal",

        calendarClass:
            "mood-normal"

    },


    "ดี": {

        emoji: "🙂",

        bulbClass:
            "bulb-good",

        calendarClass:
            "mood-good"

    },


    "ดีมาก": {

        emoji: "🥰",

        bulbClass:
            "bulb-great",

        calendarClass:
            "mood-great"

    }

};



/* =====================================================
   THAI MONTHS
===================================================== */

const thaiMonths = [

    "มกราคม",
    "กุมภาพันธ์",
    "มีนาคม",
    "เมษายน",
    "พฤษภาคม",
    "มิถุนายน",
    "กรกฎาคม",
    "สิงหาคม",
    "กันยายน",
    "ตุลาคม",
    "พฤศจิกายน",
    "ธันวาคม"

];



/* =====================================================
   CALENDAR STATE
===================================================== */

const now =
    new Date();

let calendarYear =
    now.getFullYear();

let calendarMonth =
    now.getMonth();



/* =====================================================
   SCORE
===================================================== */

scoreInput.addEventListener(
    "input",
    () => {

        scoreValue.textContent =
            scoreInput.value;

    }
);



/* =====================================================
   EXERCISE TYPE
===================================================== */

exerciseTypeInput.addEventListener(
    "change",
    () => {

        if (
            exerciseTypeInput.value ===
            "อื่น ๆ"
        ) {

            customExerciseGroup.classList.add(
                "show"
            );

            customExerciseInput.required =
                true;

            customExerciseInput.focus();

        } else {

            customExerciseGroup.classList.remove(
                "show"
            );

            customExerciseInput.required =
                false;

            customExerciseInput.value =
                "";

        }

    }
);



/* =====================================================
   TODAY
===================================================== */

function getTodayString() {

    const today =
        new Date();


    const year =
        today.getFullYear();


    const month =
        String(
            today.getMonth() + 1
        ).padStart(2, "0");


    const day =
        String(
            today.getDate()
        ).padStart(2, "0");


    return `${year}-${month}-${day}`;

}



/* =====================================================
   FORMAT DATE
===================================================== */

function formatDate(
    dateString
) {

    const [
        year,
        month,
        day
    ] =
        dateString.split("-");


    return `${day}/${month}/${year}`;

}



/* =====================================================
   SAVE LOCAL STORAGE
===================================================== */

function saveData() {

    localStorage.setItem(
        "healthTrackerData",
        JSON.stringify(
            healthData
        )
    );

}



/* =====================================================
   SORT DATA
===================================================== */

function getSortedData() {

    return [...healthData].sort(
        (a, b) =>
            a.date.localeCompare(
                b.date
            )
    );

}



/* =====================================================
   FIND DATA BY DATE
===================================================== */

function getDataByDate(
    dateString
) {

    return healthData.find(
        item =>
            item.date ===
            dateString
    );

}



/* =====================================================
   FORM SUBMIT
===================================================== */

form.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        const date =
            dateInput.value;


        const mood =
            document.querySelector(
                'input[name="mood"]:checked'
            )?.value;


        const reading =
            Number(
                readingInput.value
            );


        const exercise =
            Number(
                exerciseInput.value
            );


        const selectedExercise =
            exerciseTypeInput.value;


        /*
           ถ้าเลือก "อื่น ๆ"
           ใช้ข้อความที่ผู้ใช้พิมพ์
        */

        let exerciseType =
            selectedExercise;


        if (
            selectedExercise ===
            "อื่น ๆ"
        ) {

            const customValue =
                customExerciseInput.value.trim();


            if (!customValue) {

                alert(
                    "กรุณาพิมพ์ประเภทการออกกำลังกายด้วยนะ 🌷"
                );

                customExerciseInput.focus();

                return;

            }


            exerciseType =
                customValue;

        }


        const score =
            Number(
                scoreInput.value
            );



        /* Validate */

        if (!date) {

            alert(
                "กรุณาเลือกวันที่ก่อนนะ 🌷"
            );

            return;

        }


        if (!mood) {

            alert(
                "กรุณาเลือกอารมณ์ของวันนี้ก่อนนะ 💗"
            );

            return;

        }



        /* =========================================
           NEW DATA
        ========================================= */

        const newData = {

            id:
                Date.now(),

            date:
                date,

            mood:
                mood,

            reading:
                reading,

            exercise:
                exercise,

            exerciseType:
                exerciseType,

            score:
                score

        };



        /* =========================================
           CHECK EXISTING DATE
        ========================================= */

        const existingIndex =
            healthData.findIndex(
                item =>
                    item.date ===
                    date
            );



        if (
            existingIndex !==
            -1
        ) {

            newData.id =
                healthData[
                    existingIndex
                ].id;


            healthData[
                existingIndex
            ] =
                newData;


            alert(
                "อัปเดตข้อมูลของวันนี้แล้ว 💕"
            );

        } else {

            healthData.push(
                newData
            );


            alert(
                "บันทึกข้อมูลเรียบร้อยแล้ว 🌷"
            );

        }



        saveData();



        /* Show result button */

        savedMessage.classList.add(
            "show"
        );


        savedMessage.scrollIntoView({

            behavior:
                "smooth",

            block:
                "center"

        });

    }
);



/* =====================================================
   SHOW RESULTS
===================================================== */

showResultsButton.addEventListener(
    "click",
    () => {

        inputPage.classList.add(
            "hidden"
        );


        resultsPage.classList.remove(
            "hidden"
        );


        renderResults();


        window.scrollTo({

            top:
                0,

            behavior:
                "smooth"

        });

    }
);



/* =====================================================
   BACK TO INPUT
===================================================== */

backToInputButton.addEventListener(
    "click",
    () => {

        resultsPage.classList.add(
            "hidden"
        );


        inputPage.classList.remove(
            "hidden"
        );


        window.scrollTo({

            top:
                0,

            behavior:
                "smooth"

        });

    }
);



/* =====================================================
   CALENDAR
===================================================== */

function renderCalendar() {

    calendarDays.innerHTML =
        "";


    calendarTitle.textContent =
        `${thaiMonths[calendarMonth]} ${calendarYear + 543}`;



    const firstDay =
        new Date(
            calendarYear,
            calendarMonth,
            1
        ).getDay();


    const daysInMonth =
        new Date(
            calendarYear,
            calendarMonth + 1,
            0
        ).getDate();



    /* Empty cells */

    for (
        let i = 0;
        i < firstDay;
        i++
    ) {

        const empty =
            document.createElement(
                "div"
            );


        empty.className =
            "calendar-day empty";


        calendarDays.appendChild(
            empty
        );

    }



    /* Days */

    for (
        let day = 1;
        day <= daysInMonth;
        day++
    ) {

        const button =
            document.createElement(
                "button"
            );


        button.type =
            "button";


        button.className =
            "calendar-day";



        const monthString =
            String(
                calendarMonth + 1
            ).padStart(2, "0");


        const dayString =
            String(day)
                .padStart(2, "0");


        const dateString =
            `${calendarYear}-${monthString}-${dayString}`;



        const data =
            getDataByDate(
                dateString
            );



        /* Today */

        if (
            dateString ===
            getTodayString()
        ) {

            button.classList.add(
                "today"
            );

        }



        /* Has data */

        if (data) {

            const config =
                moodConfig[
                    data.mood
                ];


            button.classList.add(
                "has-data"
            );


            if (config) {

                button.classList.add(
                    config.calendarClass
                );

            }


            button.title =
                `บันทึกแล้ว: ${data.mood}`;

        }



        button.textContent =
            day;



        /* Click date */

        button.addEventListener(
            "click",
            () => {

                resultsPage.classList.add(
                    "hidden"
                );


                inputPage.classList.remove(
                    "hidden"
                );


                dateInput.value =
                    dateString;


                loadDataToForm(
                    dateString
                );


                window.scrollTo({

                    top:
                        0,

                    behavior:
                        "smooth"

                });

            }
        );



        calendarDays.appendChild(
            button
        );

    }

}



/* =====================================================
   PREVIOUS MONTH
===================================================== */

prevMonthButton.addEventListener(
    "click",
    () => {

        calendarMonth--;


        if (
            calendarMonth < 0
        ) {

            calendarMonth =
                11;

            calendarYear--;

        }


        renderCalendar();

    }
);



/* =====================================================
   NEXT MONTH
===================================================== */

nextMonthButton.addEventListener(
    "click",
    () => {

        calendarMonth++;


        if (
            calendarMonth > 11
        ) {

            calendarMonth =
                0;

            calendarYear++;

        }


        renderCalendar();

    }
);



/* =====================================================
   LOAD DATA TO FORM
===================================================== */

function loadDataToForm(
    dateString
) {

    const data =
        getDataByDate(
            dateString
        );



    /* Reset mood */

    document
        .querySelectorAll(
            'input[name="mood"]'
        )
        .forEach(
            radio => {

                radio.checked =
                    false;

            }
        );



    if (!data) {

        readingInput.value =
            "";

        exerciseInput.value =
            "";

        exerciseTypeInput.value =
            "ไม่ได้ออกกำลังกาย";

        customExerciseInput.value =
            "";

        customExerciseInput.required =
            false;

        customExerciseGroup.classList.remove(
            "show"
        );

        scoreInput.value =
            5;

        scoreValue.textContent =
            5;

        return;

    }



    /* Mood */

    const moodRadio =
        document.querySelector(
            `input[name="mood"][value="${data.mood}"]`
        );


    if (moodRadio) {

        moodRadio.checked =
            true;

    }



    /* Reading */

    readingInput.value =
        data.reading;



    /* Exercise */

    exerciseInput.value =
        data.exercise;



    /*
       Exercise type
       Check if it is one of
       the predefined options
    */

    const options =
        Array.from(
            exerciseTypeInput.options
        );


    const predefined =
        options.some(
            option =>
                option.value ===
                data.exerciseType
        );



    if (predefined) {

        exerciseTypeInput.value =
            data.exerciseType;


        customExerciseGroup.classList.remove(
            "show"
        );


        customExerciseInput.value =
            "";


        customExerciseInput.required =
            false;

    } else {

        /*
           ข้อมูลที่เคยพิมพ์เอง
        */

        exerciseTypeInput.value =
            "อื่น ๆ";


        customExerciseGroup.classList.add(
            "show"
        );


        customExerciseInput.value =
            data.exerciseType;


        customExerciseInput.required =
            true;

    }



    /* Score */

    scoreInput.value =
        data.score;


    scoreValue.textContent =
        data.score;

}



/* =====================================================
   MOOD TRACKER
===================================================== */

function renderMoodTracker() {

    moodTracker.innerHTML =
        "";


    const data =
        getSortedData();



    if (
        data.length ===
        0
    ) {

        moodTracker.innerHTML = `

            <div class="empty-state">

                ยังไม่มีข้อมูล
                ลองบันทึกวันแรกดูนะ 🌱

            </div>

        `;

        return;

    }



    data.forEach(
        item => {

            const config =
                moodConfig[
                    item.mood
                ];


            const moodDay =
                document.createElement(
                    "div"
                );


            moodDay.className =
                "mood-day";


            moodDay.innerHTML = `

                <div
                    class="mood-bulb ${config.bulbClass}"
                    title="${item.mood}"
                >

                    ${config.emoji}

                </div>


                <div class="mood-day-date">

                    ${formatDate(item.date)}

                </div>


                <div class="mood-day-name">

                    ${item.mood}

                </div>

            `;


            moodTracker.appendChild(
                moodDay
            );

        }
    );

}



/* =====================================================
   HISTORY
===================================================== */

function renderHistory() {

    historyList.innerHTML =
        "";


    const data =
        getSortedData()
            .reverse();



    if (
        data.length ===
        0
    ) {

        historyList.innerHTML = `

            <div class="empty-state">

                ยังไม่มีบันทึก 🌷

            </div>

        `;

        return;

    }



    data.forEach(
        item => {

            const config =
                moodConfig[
                    item.mood
                ];


            const historyItem =
                document.createElement(
                    "div"
                );


            historyItem.className =
                "history-item";



            const exerciseText =
                item.exercise > 0
                    ? `🏃 ${item.exercise} นาที (${item.exerciseType})`
                    : `🏃 ${item.exercise} นาที`;



            historyItem.innerHTML = `

                <div class="history-date">

                    📅
                    ${formatDate(item.date)}

                </div>


                <div class="history-mood">

                    ${config.emoji}

                    ${item.mood}

                </div>


                <div class="history-info">

                    📚
                    ${item.reading}
                    นาที

                    <br>

                    ${exerciseText}

                </div>


                <div class="history-score">

                    ⭐
                    ${item.score}/10

                </div>


                <button
                    class="delete-button"
                    onclick="deleteData(${item.id})"
                >

                    🗑️

                </button>

            `;


            historyList.appendChild(
                historyItem
            );

        }
    );

}



/* =====================================================
   DELETE ONE
===================================================== */

function deleteData(
    id
) {

    const confirmed =
        confirm(
            "ต้องการลบข้อมูลวันนี้ใช่ไหม? 🥺"
        );


    if (!confirmed) {

        return;

    }


    healthData =
        healthData.filter(
            item =>
                item.id !== id
        );


    saveData();


    renderResults();

}



/* =====================================================
   CLEAR ALL
===================================================== */

clearAllButton.addEventListener(
    "click",
    () => {

        if (
            healthData.length ===
            0
        ) {

            alert(
                "ตอนนี้ยังไม่มีข้อมูลให้ลบนะ 🌱"
            );

            return;

        }


        const confirmed =
            confirm(
                "ต้องการล้างข้อมูลทั้งหมดจริง ๆ ใช่ไหม?\n\nข้อมูลทั้งหมดจะถูกลบและไม่สามารถกู้คืนได้ 🥺"
            );


        if (!confirmed) {

            return;

        }


        healthData = [];


        localStorage.removeItem(
            "healthTrackerData"
        );


        form.reset();


        scoreInput.value =
            5;


        scoreValue.textContent =
            5;


        dateInput.value =
            getTodayString();


        customExerciseGroup.classList.remove(
            "show"
        );


        customExerciseInput.value =
            "";


        customExerciseInput.required =
            false;


        savedMessage.classList.remove(
            "show"
        );


        renderResults();


        alert(
            "ล้างข้อมูลทั้งหมดเรียบร้อยแล้ว 🌷"
        );

    }
);



/* =====================================================
   ACTIVITY CHART
===================================================== */

let activityChart =
    null;


function renderActivityChart() {

    const canvas =
        document.getElementById(
            "activityChart"
        );


    const data =
        getSortedData();


    const labels =
        data.map(
            item =>
                formatDate(
                    item.date
                ).substring(0, 5)
        );


    const readingData =
        data.map(
            item =>
                item.reading
        );


    const exerciseData =
        data.map(
            item =>
                item.exercise
        );


    if (
        activityChart
    ) {

        activityChart.destroy();

    }


    activityChart =
        new Chart(
            canvas,
            {

                type:
                    "bar",


                data: {

                    labels:
                        labels,


                    datasets: [

                        {

                            label:
                                "อ่านหนังสือ 📚",

                            data:
                                readingData,

                            backgroundColor:
                                "#c8b5ed",

                            borderRadius:
                                10,

                            borderSkipped:
                                false

                        },


                        {

                            label:
                                "ออกกำลังกาย 🏃",

                            data:
                                exerciseData,

                            backgroundColor:
                                "#a9d8bd",

                            borderRadius:
                                10,

                            borderSkipped:
                                false

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,


                    plugins: {

                        legend: {

                            labels: {

                                font: {

                                    family:
                                        "Kanit"

                                }

                            }

                        }

                    },


                    scales: {

                        x: {

                            grid: {

                                display:
                                    false

                            }

                        },


                        y: {

                            beginAtZero:
                                true,

                            title: {

                                display:
                                    true,

                                text:
                                    "นาที"

                            }

                        }

                    }

                }

            }
        );

}



/* =====================================================
   SCORE CHART
===================================================== */

let scoreChart =
    null;


function renderScoreChart() {

    const canvas =
        document.getElementById(
            "scoreChart"
        );


    const data =
        getSortedData();


    const labels =
        data.map(
            item =>
                formatDate(
                    item.date
                ).substring(0, 5)
        );


    const scores =
        data.map(
            item =>
                item.score
        );


    if (
        scoreChart
    ) {

        scoreChart.destroy();

    }


    scoreChart =
        new Chart(
            canvas,
            {

                type:
                    "line",


                data: {

                    labels:
                        labels,


                    datasets: [

                        {

                            label:
                                "คะแนนที่ให้ตัวเอง",

                            data:
                                scores,

                            borderColor:
                                "#f09abb",

                            backgroundColor:
                                "rgba(240,154,187,.15)",

                            fill:
                                true,

                            tension:
                                .4,

                            pointBackgroundColor:
                                "#f09abb",

                            pointBorderColor:
                                "#fff",

                            pointBorderWidth:
                                3,

                            pointRadius:
                                6

                        }

                    ]

                },


                options: {

                    responsive:
                        true,

                    maintainAspectRatio:
                        false,


                    plugins: {

                        legend: {

                            display:
                                false

                        }

                    },


                    scales: {

                        x: {

                            grid: {

                                display:
                                    false

                            }

                        },


                        y: {

                            min:
                                1,

                            max:
                                10,

                            ticks: {

                                stepSize:
                                    1

                            }

                        }

                    }

                }

            }
        );

}



/* =====================================================
   RENDER RESULTS
===================================================== */

function renderResults() {

    renderCalendar();

    renderMoodTracker();

    renderHistory();

    renderActivityChart();

    renderScoreChart();

}



/* =====================================================
   INITIAL
===================================================== */

dateInput.value =
    getTodayString();


renderCalendar();